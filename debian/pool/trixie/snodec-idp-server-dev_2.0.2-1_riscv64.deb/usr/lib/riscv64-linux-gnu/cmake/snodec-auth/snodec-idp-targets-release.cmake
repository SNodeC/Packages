#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec-auth::auth-idp" for configuration "Release"
set_property(TARGET snodec-auth::auth-idp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec-auth::auth-idp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libauth-idp.a"
  )

list(APPEND _cmake_import_check_targets snodec-auth::auth-idp )
list(APPEND _cmake_import_check_files_for_snodec-auth::auth-idp "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libauth-idp.a" )

# Import target "snodec-auth::db-sqlite" for configuration "Release"
set_property(TARGET snodec-auth::db-sqlite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec-auth::db-sqlite PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libdb-sqlite.a"
  )

list(APPEND _cmake_import_check_targets snodec-auth::db-sqlite )
list(APPEND _cmake_import_check_files_for_snodec-auth::db-sqlite "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libdb-sqlite.a" )

# Import target "snodec-auth::nayuki-qrcodegen" for configuration "Release"
set_property(TARGET snodec-auth::nayuki-qrcodegen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec-auth::nayuki-qrcodegen PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libnayuki-qrcodegen.a"
  )

list(APPEND _cmake_import_check_targets snodec-auth::nayuki-qrcodegen )
list(APPEND _cmake_import_check_files_for_snodec-auth::nayuki-qrcodegen "${_IMPORT_PREFIX}/lib/riscv64-linux-gnu/libnayuki-qrcodegen.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
