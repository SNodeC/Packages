#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::mqtt" for configuration "Release"
set_property(TARGET snodec::mqtt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::mqtt PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/iot/mqtt/libsnodec-mqtt.so.2.1.0"
  IMPORTED_SONAME_RELEASE "libsnodec-mqtt.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::mqtt )
list(APPEND _cmake_import_check_files_for_snodec::mqtt "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/iot/mqtt/libsnodec-mqtt.so.2.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
