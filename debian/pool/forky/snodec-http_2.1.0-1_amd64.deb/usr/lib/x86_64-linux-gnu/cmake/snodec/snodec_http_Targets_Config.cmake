set(HTTP_COMPILE_DIR snode.c/http)
set(HTTP_COMPILE_LIBDIR /work/build-product/snode.c/http)
set(HTTP_UPGRADE_COMPILE_LIBDIR /work/build-product/snode.c/http/upgrade)

set(HTTP_INSTALL_DIR snode.c/web/http)
set(HTTP_INSTALL_INCLUDEDIR include/snode.c/web/http)
set(HTTP_INSTALL_LIBDIR lib/x86_64-linux-gnu/snode.c/web/http)
set(HTTP_UPGRADE_INSTALL_LIBDIR lib/x86_64-linux-gnu/snode.c/web/http/upgrade)
set(HTTP_INSTALL_RPATH /usr/lib/x86_64-linux-gnu/snode.c/web/http)
