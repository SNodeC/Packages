
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was AISuiteConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/arm-linux-gnueabihf/cmake/AISuite" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
find_dependency(nlohmann_json 3.11 CONFIG QUIET)
if(NOT TARGET nlohmann_json::nlohmann_json)
    find_path(AISUITE_NLOHMANN_JSON_INCLUDE_DIR nlohmann/json.hpp REQUIRED)
    add_library(nlohmann_json::nlohmann_json INTERFACE IMPORTED)
    set_target_properties(
        nlohmann_json::nlohmann_json
        PROPERTIES INTERFACE_INCLUDE_DIRECTORIES
                   "${AISUITE_NLOHMANN_JSON_INCLUDE_DIR}"
    )
endif()
set(_AISUITE_SNODEC_COMPONENTS
    core net-un-stream-legacy net-in-stream-legacy net-in6-stream-legacy
)
if("ON" STREQUAL "ON")
    list(APPEND _AISUITE_SNODEC_COMPONENTS websocket-server http-client
         websocket-client)
endif()
find_dependency(snodec 2.0 CONFIG COMPONENTS ${_AISUITE_SNODEC_COMPONENTS})
if("ON" STREQUAL "ON")
    find_dependency(OpenSSL)
    find_dependency(snodec 2.0 CONFIG COMPONENTS http-client http-server net-in-stream-tls)
endif()
unset(_AISUITE_SNODEC_COMPONENTS)

include("${CMAKE_CURRENT_LIST_DIR}/AISuiteTargets.cmake")
check_required_components(AISuite)
