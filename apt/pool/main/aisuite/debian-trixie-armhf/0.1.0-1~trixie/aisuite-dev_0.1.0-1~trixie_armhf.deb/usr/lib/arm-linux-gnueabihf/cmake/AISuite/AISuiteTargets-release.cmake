#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AISuite::HttpStreaming" for configuration "Release"
set_property(TARGET AISuite::HttpStreaming APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AISuite::HttpStreaming PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "snodec::http-client;snodec::net-in-stream-tls;snodec::net-in-stream-legacy"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-http-streaming.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libai-http-streaming.so.0"
  )

list(APPEND _cmake_import_check_targets AISuite::HttpStreaming )
list(APPEND _cmake_import_check_files_for_AISuite::HttpStreaming "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-http-streaming.so.0.1.0" )

# Import target "AISuite::Anthropic" for configuration "Release"
set_property(TARGET AISuite::Anthropic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AISuite::Anthropic PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-anthropic.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libai-anthropic.so.0"
  )

list(APPEND _cmake_import_check_targets AISuite::Anthropic )
list(APPEND _cmake_import_check_files_for_AISuite::Anthropic "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-anthropic.so.0.1.0" )

# Import target "AISuite::OpenAICodex" for configuration "Release"
set_property(TARGET AISuite::OpenAICodex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AISuite::OpenAICodex PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "snodec::http-server;snodec::net-un-stream-legacy;snodec::net-in-stream-legacy;snodec::net-in6-stream-legacy"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-openai-codex.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libai-openai-codex.so.0"
  )

list(APPEND _cmake_import_check_targets AISuite::OpenAICodex )
list(APPEND _cmake_import_check_files_for_AISuite::OpenAICodex "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libai-openai-codex.so.0.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
