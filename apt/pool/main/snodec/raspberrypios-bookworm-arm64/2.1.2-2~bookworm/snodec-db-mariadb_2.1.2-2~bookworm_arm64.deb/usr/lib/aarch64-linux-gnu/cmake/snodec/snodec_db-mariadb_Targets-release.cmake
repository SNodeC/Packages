#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::db-mariadb" for configuration "Release"
set_property(TARGET snodec::db-mariadb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::db-mariadb PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libsnodec-db-mariadb.so.2.1.2"
  IMPORTED_SONAME_RELEASE "libsnodec-db-mariadb.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::db-mariadb )
list(APPEND _cmake_import_check_files_for_snodec::db-mariadb "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libsnodec-db-mariadb.so.2.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
