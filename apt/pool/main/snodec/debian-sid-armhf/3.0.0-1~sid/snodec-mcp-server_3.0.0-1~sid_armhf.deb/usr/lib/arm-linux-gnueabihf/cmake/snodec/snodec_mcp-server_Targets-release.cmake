#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::mcp-server" for configuration "Release"
set_property(TARGET snodec::mcp-server APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::mcp-server PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/mcp/libsnodec-mcp-server.so.3.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-mcp-server.so.3"
  )

list(APPEND _cmake_import_check_targets snodec::mcp-server )
list(APPEND _cmake_import_check_files_for_snodec::mcp-server "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/mcp/libsnodec-mcp-server.so.3.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
