#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::http-server-express-tls-in6" for configuration "Release"
set_property(TARGET snodec::http-server-express-tls-in6 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::http-server-express-tls-in6 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/web/http/libsnodec-http-server-express-tls-in6.so.3.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-http-server-express-tls-in6.so.3"
  )

list(APPEND _cmake_import_check_targets snodec::http-server-express-tls-in6 )
list(APPEND _cmake_import_check_files_for_snodec::http-server-express-tls-in6 "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/web/http/libsnodec-http-server-express-tls-in6.so.3.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
