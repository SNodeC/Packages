#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::mcp-server-http" for configuration "Release"
set_property(TARGET snodec::mcp-server-http APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::mcp-server-http PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/mcp/libsnodec-mcp-server-http.so.3.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-mcp-server-http.so.3"
  )

list(APPEND _cmake_import_check_targets snodec::mcp-server-http )
list(APPEND _cmake_import_check_files_for_snodec::mcp-server-http "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/mcp/libsnodec-mcp-server-http.so.3.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
