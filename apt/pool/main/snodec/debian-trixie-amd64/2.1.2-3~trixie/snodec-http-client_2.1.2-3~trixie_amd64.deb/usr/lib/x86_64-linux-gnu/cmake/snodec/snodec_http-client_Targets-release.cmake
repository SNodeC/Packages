#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::http-client" for configuration "Release"
set_property(TARGET snodec::http-client APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::http-client PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/web/http/libsnodec-http-client.so.2.1.2"
  IMPORTED_SONAME_RELEASE "libsnodec-http-client.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::http-client )
list(APPEND _cmake_import_check_files_for_snodec::http-client "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/snode.c/web/http/libsnodec-http-client.so.2.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
