set(HTTP_COMPILE_DIR snode.c/http)
set(HTTP_COMPILE_LIBDIR /tmp/codex/build/snodec/wave/snode.c/http)
set(HTTP_UPGRADE_COMPILE_LIBDIR /tmp/codex/build/snodec/wave/snode.c/http/upgrade)

set(HTTP_INSTALL_DIR snode.c/web/http)
set(HTTP_INSTALL_INCLUDEDIR include/snode.c/web/http)
set(HTTP_INSTALL_LIBDIR lib/arm-linux-gnueabihf/snode.c/web/http)
set(HTTP_UPGRADE_INSTALL_LIBDIR lib/arm-linux-gnueabihf/snode.c/web/http/upgrade)
set(HTTP_INSTALL_RPATH /usr/lib/arm-linux-gnueabihf/snode.c/web/http)
