#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::http-server" for configuration "Release"
set_property(TARGET snodec::http-server APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::http-server PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/web/http/libsnodec-http-server.so.2.1.2"
  IMPORTED_SONAME_RELEASE "libsnodec-http-server.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::http-server )
list(APPEND _cmake_import_check_files_for_snodec::http-server "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/snode.c/web/http/libsnodec-http-server.so.2.1.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
